-- \c mydb; -- Database Connection.

-- \i 01_tables.sql -- Create Tables.
-- \i 02_triggers.sql -- Create Triggers.