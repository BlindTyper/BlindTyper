package deleterequest

import "log"

type ProfileObject struct {
	id int
}

func (profile *ProfileObject) DeleteProfile() (status bool, error error) {
	// sql request to delete unique record in profile db with id =  id
	log.Printf("Profile with id %v was deleted.", profile.id)

	return status, error
}

func SendDeleteRequest(resource *ProfileObject) {
	resource.DeleteProfile()
}
