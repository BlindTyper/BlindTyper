package editrequest

import "database/sql"

type ProfileObject struct {
	Name            string
	Img             string
	Password        string
	Password_repeat string
	email           string
}

func SendEditProfilePasswordRequest(resource *ProfileObject, s *sql.DB) (status bool, error error) {
	return resource.ChangePassword()
}
func (profile *ProfileObject) ChangePassword() (status bool, error error) {
	// подключение к БД и изменение password
	profile.Password = "new password"

	return status, error
}

func SendEditProfileNameRequest(resource *ProfileObject, s *sql.DB) (status bool, error error) {
	return resource.ChangeName()
}
func (profile *ProfileObject) ChangeName() (status bool, error error) {
	// подключение к БД и изменение юза
	profile.Name = "newName"

	return status, error
}

func SendEditProfileImageRequest(resource *ProfileObject, s *sql.DB) (status bool, error error) {
	return resource.ChangeImage()
}
func (profile *ProfileObject) ChangeImage() (status bool, error error) {
	// подключение к БД и изменение img
	profile.Img = "new img path"

	return status, error
}

func SendEditProfileEmailRequest(resource *ProfileObject, s *sql.DB) (status bool, error error) {
	return resource.ChangeEmail()
}
func (profile *ProfileObject) ChangeEmail() (status bool, error error) {
	// подключение к БД и изменение email
	profile.email = "new email"

	return status, error
}
