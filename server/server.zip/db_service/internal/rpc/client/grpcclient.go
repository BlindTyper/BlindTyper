package client

// there will be client to another service

import (
	"log"
)

func StartClient() {
	log.Println("Client to ... Started")
}
