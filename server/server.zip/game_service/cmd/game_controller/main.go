package main

import (
	"game_service/internal/listener"
	"log"
)

func main() {
	log.Println("game_controller started.")
	listener.ConnHandler()
}
