package main

import (
	"log"
)

func main(){
	log.Println("users_controller started.")	
}