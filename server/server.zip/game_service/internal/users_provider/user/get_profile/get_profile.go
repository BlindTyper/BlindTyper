package getprofile

import (
	"log"
)

func Get_profile() {
	log.Println("Profile was sent")
}
