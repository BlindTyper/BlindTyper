package main

import (
	"gateway/internal/listener"
	"log"
)

func main() {
	log.Println("gateway started")

	listener.ConnHandler()
	/*
		start listening
		if conn -> handle( get type of req)
			-> send to determined service worker.
	*/
}

/*
	internal:
		- listen for connections
		- analyze connections
		- route connections
	global:
		- currently nothing
*/
