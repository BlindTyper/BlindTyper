package router

import (
	"context"
	"io"
	"log"
	"net/http"
	"strings"
)

var routes = map[string]string{
	"/auth/":  "http://auth:8081/",
	"/data/":  "http://data:8082/",
	"/game/":  "http://game:8083/",
	"/admin/": "http://admin:8084/",
}

func RouteRequest(Logger *log.Logger, ctx context.Context,
	req *http.Request, wrt http.ResponseWriter) {

	log.Println("Router got request. . .")

	for prefix, targetBase := range routes {
		if strings.HasPrefix(req.URL.Path, prefix) {
			target := targetBase + strings.TrimPrefix(req.URL.Path, prefix)

			log.Println("proxying to:", target)

			ProxyRequest(req, wrt, target)
			return
		}
	}

	http.NotFound(wrt, req)
}

func ProxyRequest(r *http.Request, w http.ResponseWriter, target string) {
	/*
		Sending POST request to auth_service server
	*/

	body, err := io.ReadAll(r.Body)
	if err != nil {
		http.Error(w, "failed to read req body", http.StatusBadRequest)
		return
	}
	defer r.Body.Close()

	req, err := http.NewRequest(r.Method, target, io.NopCloser(strings.NewReader(string(body))))
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	req.Header = r.Header.Clone()

	client := &http.Client{}
	resp, err := client.Do(req)

	if err != nil {
		http.Error(w, err.Error(), http.StatusBadGateway)
		return
	}
	defer resp.Body.Close()

	for k, v := range resp.Header {
		w.Header()[k] = v
	}
	w.WriteHeader(resp.StatusCode)
	io.Copy(w, resp.Body)
}
