package jwtgenerator

import (
	"log"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

func GenerateJWT(Username string) (answer string, err error) { // return type is JWT. string?
	// source string - example. check format
	log.Println("JWT generated")

	// return new JWT for the source. add to the HEADER and return

	hmacSampleSecret := []byte("Heh, it's secret" + Username)

	claims := &jwt.RegisteredClaims{
		ExpiresAt: jwt.NewNumericDate(time.Unix(1516239022, 0)),
		Issuer:    "Username||Unique Id",
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	signedToken, err := token.SignedString(hmacSampleSecret)
	if err != nil {
		return "", err
	}
	return signedToken, nil
}

func ValidateJWT(source string) bool {
	// if given JWT matches internal value -> true
	return true
}
