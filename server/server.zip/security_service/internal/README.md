# Реализация внутренней логики auth-service.

# ToDo(
    - Auth/Register
        -2FA?
    
    - JWT providing

    - middleware tool for other services
)