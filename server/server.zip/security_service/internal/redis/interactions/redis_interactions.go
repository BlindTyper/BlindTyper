package rediscrud

import (
	"log"
)

func Test() {
	log.Println("hw.")
}
