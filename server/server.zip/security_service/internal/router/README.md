# Request Router
	* used to route request inside of auth_service server.