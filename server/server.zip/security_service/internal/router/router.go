// Package router provides data transfering between modules of the auth-service
package router

import (
	"context"
	"log"
	"net/http"
	"security_service/internal/authentification/login"
	"security_service/internal/authentification/register"
	"security_service/pkg/middleware"
	"strings"
)

/* var routes = map[string]http.HandlerFunc{
    "login":    LoginHandler,
    "register": RegisterHandler,
    "main":     MainHandler,
}

func RouteRequest(Logger *log.Logger, ctx context.Context, req *http.Request, wrt http.ResponseWriter) {
    path := strings.TrimPrefix(req.URL.Path, "/auth/")
    handler, ok := routes[path]
    if !ok {
        http.NotFound(wrt, req)
        return
    }
    handler(wrt, req)
}
*/

func RouteRequest(Logger *log.Logger, ctx context.Context,
	req *http.Request, wrt http.ResponseWriter) {
	/*
		add check for internal project sertificate
	*/
	log.Println("Router got request. . .")

	path := strings.TrimPrefix(req.URL.Path, "/auth/")

	switch path {
	case "/login":
		login.LoginHandler(wrt, req)
	case "/register":
		register.RegisterHandler(wrt, req)
	case "/main":
		/*	sample	*/
		mw := &middleware.MiddlewareData{}
		result := mw.MiddlewareAuth(req)

		if result.Status {
			log.Println("security/router: Access granted | mw answer:", result.Answer)
			wrt.WriteHeader(http.StatusOK)
			wrt.Write([]byte(`{"status: "ok", "message":"authorized access""}`))
		} else {
			log.Println("Access denied")
			http.Error(wrt, "Unathorized", http.StatusUnauthorized)
		}
	default:
		http.NotFound(wrt, req)
	}
}
