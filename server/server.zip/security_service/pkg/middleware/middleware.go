package middleware

import (
	"log"
	"net/http"
)

type MiddlewareData struct {
	Answer string
	Status bool
}

func (mwdata *MiddlewareData) MiddlewareAuth(req *http.Request) *MiddlewareData {
	log.Println("MiddlewareAuth module got request")

	mwdata.Answer = "string"
	mwdata.Status = true

	return mwdata
}

// middleware will provide shared functions to check auth

/*
	Scenarios:
		gateway:
			- isAuth?
			- JWTtoken?
		db:
			- isAllowed?
		game:
			- isAccess?
			- JWTtoken?
			toDo()
				- Websockets access?

*/
